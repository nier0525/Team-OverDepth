#pragma once

class Quaternion
{
public:
	float x;
	float y;
	float z;
	float w;

	Quaternion()
	{
		x = 0;
		y = 0;
		z = 0;
		w = 0;
	}
	
};